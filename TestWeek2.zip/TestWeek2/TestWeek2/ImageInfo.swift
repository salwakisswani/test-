//
//  ImageInfo.swift
//  TestWeek2
//
//  Created by Salwa Kisswani on 6/28/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import Foundation

struct ImageInfo: Decodable {
    
    let mediumURL: String
    let originalURL: String
    
    enum CodingKeys: String, CodingKey {
        case mediumURL = "medium"
        case originalURL = "original"
    }
}
