//
//  ViewController.swift
//  TestWeek2
//
//  Created by Salwa Kisswani on 6/28/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//
import UIKit

class ViewController {
    
    let networkController: NetworkProtocol
    let showURLString = "https://api.tvmaze.com/shows/82?embed=seasons&embed=episodes"
    
    init(networkController: NetworkProtocol = NetworkController()) {
        self.networkController = networkController
    }
    
    // MARK: - Create
    
    func getShow(completionHandler: @escaping ([[Episode]]) -> Void) {
        networkController.getData(from: showURLString) { (data, error) in
            if let data = data {
                do {
                    let myShow = try JSONDecoder().decode(Show.self, from: data)
                    print(myShow.name)
                    // below is an example of string interpolation \(someValue)
                    print("\(myShow.runtime) minutes")
                    print(myShow.episodes.count)
                    
                    // call some sort of sort function, then return the array of seasons (array of array of episodes)
                    completionHandler(self.sortShowIntoSeasons(show: myShow))
                } catch let error {
                    print(error.localizedDescription)
                    completionHandler([])
                }
            }
        }
    }
    
    // MARK: - Helper methods
    
    func sortShowIntoSeasons(show: Show) -> [[Episode]] {
        var seasons: [[Episode]] = []
        
        // Step 1: Sort array by season and episode
        let sorted = show.episodes.sorted { (episode1, episode2) -> Bool in
            if episode1.season == episode2.season {
                return episode1.episodeNumber < episode2.episodeNumber
            } else {
                return episode1.season < episode2.season
            }
        }
        // step 2: Loop through that array, and start adding episodes to sub arrays
        guard let last = sorted.last else { return [] }
        for _ in 1...last.season {
            seasons.append([])
        }
        for episode in sorted {
            seasons[episode.season - 1].append(episode)
        }
        return seasons
    }
}
