//
//  EpisodeTableViewController.swift
//  TestWeek2
//
//  Created by Salwa Kisswani on 6/28/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit
class EpisodeTableViewController: UIViewController {
    
    @IBOutlet var episodeTableView: UITableView!
    
    var seasonsArray: [[Episode]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        episodeTableView.dataSource = self
        episodeTableView.register(UITableViewCell.self, forCellReuseIdentifier: "episodeCell")
        ViewController().getShow { (seasons) in
            
            self.seasonsArray = seasons
            DispatchQueue.main.async {
                self.episodeTableView.reloadData()
            }
            
        }
    }


extension EpisodeTableViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Season \(section + 1)"
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return seasonsArray.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return seasonsArray[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "episodeCell", for: indexPath)
        cell.textLabel?.text = seasonsArray[indexPath.section][indexPath.row].name
        return cell
    }
}

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    <#code#>
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    <#code#>
}
