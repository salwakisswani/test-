//
//  Episode.swift
//  TestWeek2
//
//  Created by Salwa Kisswani on 6/28/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import Foundation

struct Episode: Decodable {
    
    let name: String
    let season: Int
    let episodeNumber: Int
    let airdate: String
    let airtime: String
    let airstamp: String
    let imageInfo: ImageInfo?
    let summary: String?
    
    enum CodingKeys: String, CodingKey {
        case name, airdate, airtime, airstamp, season, summary
        case episodeNumber = "number"
        case imageInfo = "image"
    }
}
