//
//  NetworkController.swift
//  TestWeek2
//
//  Created by Salwa Kisswani on 6/28/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//
import Foundation

class NetworkController: NetworkProtocol {
    
    
    func getData(from urlString: String, completionHandler: @escaping (Data?, Error?) -> Void) {
        if let url = URL(string: urlString) {
            let dataTaskCompletion: (Data?, URLResponse?, Error?) -> Void = {
                completionHandler($0, $2)
            }
            URLSession.shared.dataTask(with: url, completionHandler: dataTaskCompletion)
            URLSession.shared.dataTask(with: url) { (data, urlResponse, error) in
                completionHandler(data, error)
                }.resume()
        }
    }
}

protocol NetworkProtocol {
    func getData(from urlString: String, completionHandler: @escaping (Data?, Error?) -> Void)
}
