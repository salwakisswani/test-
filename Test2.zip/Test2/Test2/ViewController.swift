//
//  ViewController.swift
//  Test2
//
//  Created by Salwa Kisswani on 6/28/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit
    
    class ShowController {
        
        let networkController: NetworkProtocol
        let showURLString = "https://api.tvmaze.com/shows/82?embed=seasons&embed=episodes"
        
        init(networkController: NetworkProtocol = NetworkController()) {
            self.networkController = networkController
        }
        
        // MARK: - Create
        
        func getShow(completionHandler: @escaping ([[Episode]]) -> Void) {
            networkController.getData(from: showURLString) { (data, error) in
                if let data = data {
                    do {
                        let myShow = try JSONDecoder().decode(Show.self, from: data)
                        print(myShow.name)
                        // below is an example of string interpolation \(someValue)
                        print("\(myShow.runtime) minutes")
                        print(myShow.episodes.count)
                        
                        // call some sort of sort function, then return the array of seasons (array of array of episodes)
                        completionHandler(self.sortShowIntoSeasons(show: myShow))
                    } catch let error {
                        print(error.localizedDescription)
                        completionHandler([])
                    }
                }
            }
        }
        
        
        // MARK: - Helper methods
        
        func sortShowIntoSeasons(show: Show) -> [[Episode]] {
            var seasons: [[Episode]] = []
            
            // Step 1: Sort array by season and episode
            let sorted = show.episodes.sorted { (episode1, episode2) -> Bool in
                if episode1.season == episode2.season {
                    return episode1.episodeNumber < episode2.episodeNumber
                } else {
                    return episode1.season < episode2.season
                }
            }
            // step 2: Loop through that array, and start adding episodes to sub arrays
            guard let last = sorted.last else { return [] }
            for _ in 1...last.season {
                seasons.append([])
            }
            for episode in sorted {
                seasons[episode.season - 1].append(episode)
            }
            return seasons
        }
    }


struct ImageInfo: Decodable {
    let mediumURL: String
    let originalURL: String
    
    enum CodingKeys: String, CodingKey {
        case mediumURL = "medium"
        case originalURL = "original"
    }
}

struct Episode: Decodable {
    let name: String
    let season: Int
    let episodeNumber: Int
    let airdate: String
    let airtime: String
    let airstamp: String
    let imageInfo: ImageInfo?
    let summary: String?
    
    enum CodingKeys: String, CodingKey {
        case name, airdate, airtime, airstamp, season, summary
        case episodeNumber = "number"
        case imageInfo = "image"
    }
    
}

struct Show: Decodable {
    let name: String
    let runtime: Int
    let episodes: [Episode]
    
    enum CodingKeys: String, CodingKey {
        case name
        case runtime
        case embed = "_embedded"
        case episodes
    }
}

extension Show {
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self
            , forKey: .name)
        self.runtime = try container.decode(Int.self, forKey: .runtime)
        let episodeContainer = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .embed)
        self.episodes = try episodeContainer.decode([Episode].self, forKey: .episodes)
    }
}




class EpisodeTableView: UIViewController {
    
    @IBOutlet weak var episodeTableView: UITableView!
    var seasonsArray: [[Episode]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        episodeTableView.dataSource = self as! UITableViewDataSource
        episodeTableView.register(UITableViewCell.self, forCellReuseIdentifier: "episodeCell")
        ShowController().getShow { (seasons) in
            
            self.seasonsArray = seasons
            DispatchQueue.main.async {
                self.episodeTableView.reloadData()
            }
            
        }
    }

    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Season \(section + 1)"
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return seasonsArray.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return seasonsArray[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "episodeCell", for: indexPath)
        cell.textLabel?.text = seasonsArray[indexPath.section][indexPath.row].name
        return cell
    }
}

